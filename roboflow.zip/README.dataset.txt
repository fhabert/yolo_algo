# Semi autonomous guidance > 2023-02-09 6:34pm
https://universe.roboflow.com/roboticchair-pbzrb/semi-autonomous-guidance

Provided by a Roboflow user
License: CC BY 4.0

